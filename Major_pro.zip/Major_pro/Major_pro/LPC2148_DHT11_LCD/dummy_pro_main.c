#include<LPC21xx.h>
#include<string.h>
#include"lcd.h"
#include"types.h"
#include"delay.h"
#include "kpm.h"
#include "UART_INT.h"
#include "i2c_defines.h"
#include "i2c_eeprom.h"
#include "i2c.h"
#include "uart0.h"
#include "edit.h"
#include "dht11.h"
#include "GSM.h"
#include "rtc.h"

void Enable_int(void);

extern u32 i_flag;
extern char buff[300];
extern unsigned char i;
u32 depass=1234;
u8 msg1[50]="ALERT! TEMPERATURE EXCEED ",msg2[50]="ALERT! HUMIDITY EXCEED ";
u8 pass[5],rpass[5],r_temp,r_humi,read_mobile[10],rd[50];
extern unsigned char nm_flag;
unsigned char humidity_integer, humidity_decimal, temp_integer, temp_decimal, checksum;
extern u32 hr,min,sec,date,year,day,month;


void addtime_msg(char *p)
{
	int i;
	GetRTCTimeInfo(&hr,&min,&sec);
	//GetRTCDateInfo(&dat,&month,&year);
	//GetRTCDay(&day);
	i=strlen(p);
	p[i++]='@';
	p[i++]=hr/10+48;
	p[i++]=hr%10+48;
	p[i++]=':';
	p[i++]=min/10+48;
	p[i++]=min%10+48;
	p[i++]=':';
	p[i++]=sec/10+48;
	p[i++]=sec%10+48;
	p[i]='\0';
}

main()
{
	Enable_int();
	LCD_Init();
	RTC_Init();
	IODIR0|=1<<5;
	IODIR0|=1<<22;
	init_i2c();
	InitUART0();
	Write_CMD_LCD(0x01);
	Init_KPM();
	delay_ms(100);
	Write_CMD_LCD(0x01);
	GSM_SMS_Init();
	 myitoa(depass,pass);

	 SetRTCTimeInfo(14,32,0);
	 SetRTCDateInfo(11,2,2026);
	 SetRTCDay(3);
	
	//Writing default password , mobile number , temperature and humidity into EEPROM
	 i2c_eeprom_pagewrite(I2C_EEPROM_SA,PASS_ADDR,(s8 *)pass,4);//defalut password
	 
	 i2c_eeprom_bytewrite(I2C_EEPROM_SA,TEMP_ADDR,50);//defalut temp set point
	 i2c_eeprom_bytewrite(I2C_EEPROM_SA,HUM_ADDR,50);//defalut humi set point
	i2c_eeprom_pagewrite(I2C_EEPROM_SA,MOBILE_ADDR,"xxxxxxxxxx",10);//default mobile number
	delay_s(3);
	while(1)
	{
		i_flag=0,nm_flag=0;
		i2c_eeprom_seqread(I2C_EEPROM_SA,PASS_ADDR,(s8 *)rpass,4);
		i2c_eeprom_seqread(I2C_EEPROM_SA,MOBILE_ADDR,(s8 *)read_mobile,10);
		r_temp=i2c_eeprom_randomread(I2C_EEPROM_SA,TEMP_ADDR);
		r_humi=i2c_eeprom_randomread(I2C_EEPROM_SA,HUM_ADDR);
		do
		{
			//DHT11 main
		dht11_request();
		dht11_response();
		humidity_integer = dht11_data();
		humidity_decimal = dht11_data();
		temp_integer = dht11_data();
		temp_decimal = dht11_data();
		checksum = dht11_data();
		if( (humidity_integer + humidity_decimal + temp_integer + temp_decimal) != checksum )
			Write_str_LCD("Checksum Error\r\n");
		else
		{
			time_disp();
			Write_CMD_LCD(0x94);
			Write_str_LCD("H : ");
			Write_int_LCD(humidity_integer);
			Write_DAT_LCD('.');
			Write_int_LCD(humidity_decimal);
			Write_str_LCD(" % RH ");
			Write_CMD_LCD(0xD4);
			Write_str_LCD("T : ");
			Write_int_LCD(temp_integer);
			Write_DAT_LCD('.');
			Write_int_LCD(temp_decimal);
			Write_DAT_LCD(223);
			Write_str_LCD("C");
			Write_CMD_LCD(0x94+14); // LINE 3 POS 0
			Write_str_LCD("HSP:");	// TEMPERATURE SETPOINT
			Write_int_LCD(r_humi);	// TEMPERATURE SETPOINT
			Write_CMD_LCD(0xD4+14); // LINE 3 POS 9
			Write_str_LCD("TSP:"); // HUMIDITY SETPOINT
			Write_int_LCD(r_temp);	// HUMIDITY SETPOINT
			delay_ms(1000);
			//Write_CMD_LCD(0x01);
		}
		if(temp_integer>r_temp)
		{
			IOPIN0|=(1<<22);
			addtime_msg((char *)msg1);
			send_sms((char *)msg1,(char *)read_mobile);
		}
		if(humidity_integer>r_humi)
		{
			addtime_msg((char *)msg2);
			send_sms((char *)msg2,(char *)read_mobile);
		}
		}while((i_flag==0)&&(nm_flag==0));
		if(i_flag==1)
		{
			i_flag=0;
			edit_menu();
		}
		else if(nm_flag==1)
		{
			nm_flag=0;
			memset(rd,'\0',50);
			readsms((char*)rd);
			extract((char*)rd);
			UART0_Str("AT+CMGD=1\r\n");
	i=0;memset(buff,'\0',300);
	while(i<4);
	delay_ms(500);
	buff[i] = '\0';
	delay_ms(2000);
	if(strstr(buff,"OK"))
	{
		Write_CMD_LCD(0xC0);
		Write_str_LCD("OK");
		delay_ms(1000);		
	}
	else
	{
		Write_CMD_LCD(0xC0);
		Write_str_LCD("ERROR");
		delay_ms(1000);		
	}
	Write_CMD_LCD(0x01);
		}

	}
}

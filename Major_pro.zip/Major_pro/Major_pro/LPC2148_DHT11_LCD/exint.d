.\exint.o: exint.c
.\exint.o: D:\ARM\ARM\Inc\Philips\LPC21xx.h
.\exint.o: types.h

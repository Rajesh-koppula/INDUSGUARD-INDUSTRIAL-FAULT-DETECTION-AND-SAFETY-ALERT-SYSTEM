.\gsm.o: GSM.c
.\gsm.o: D:\ARM\ARM\ARMCC\bin\..\include\string.h
.\gsm.o: UART_INT.h
.\gsm.o: lcd.h
.\gsm.o: delay.h

.\kpm.o: kpm.c
.\kpm.o: types.h
.\kpm.o: kpm_defines.h
.\kpm.o: lcd.h
.\kpm.o: delay.h
.\kpm.o: D:\ARM\ARM\Inc\Philips\LPC21xx.h

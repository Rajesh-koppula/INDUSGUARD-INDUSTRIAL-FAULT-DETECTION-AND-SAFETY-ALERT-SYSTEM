#define I2C_EEPROM_SA1 0x50 //7 bit slave Addr
#define I2C_EEPROM_SA2 0x51
#define I2C_EEPROM_SA3 0x52
#define I2C_EEPROM_SA4 0x53
#define I2C_EEPROM_SA5 0x54
#define I2C_EEPROM_SA6 0x55
#define I2C_EEPROM_SA7 0x56
#define I2C_EEPROM_SA8 0x57

.\i2c_peripheral.o: i2c_peripheral.c
.\i2c_peripheral.o: types.h
.\i2c_peripheral.o: i2c_defines.h
.\i2c_peripheral.o: D:\ARM\ARM\Inc\Philips\LPC21xx.h

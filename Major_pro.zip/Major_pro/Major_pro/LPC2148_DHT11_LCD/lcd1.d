.\lcd1.o: lcd1.c
.\lcd1.o: D:\ARM\ARM\Inc\Philips\LPC21xx.h
.\lcd1.o: delay.h
.\lcd1.o: lcd.h
.\lcd1.o: defines.h

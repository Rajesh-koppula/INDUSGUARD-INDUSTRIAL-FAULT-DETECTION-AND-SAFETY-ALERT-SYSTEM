.\rtc.o: rtc.c
.\rtc.o: D:\ARM\ARM\Inc\Philips\LPC21xx.H
.\rtc.o: rtc_defines.h
.\rtc.o: types.h
.\rtc.o: lcd.h
